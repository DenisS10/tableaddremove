// $(document).on('click','#delBtn',function (e) {
//     e.preventDefault();
//     $.get("delete.php",{'numberOfRecord':$(this).attr('i')})
//         .done(function (data) {
//             $('#'+data).closest('tr').remove();
//
//         })
//
//
//
// })