<?php
header('location: index.php');
//Сохранение в файл
//echo '<pre>';
//print_r($_POST);
//echo '</pre>';
if (isset($_POST['task'])) {
    $task = $_POST['task'];
}

$deadline = isset($_POST['deadline']) ? $_POST['deadline'] : ''; /*Выражения одинаковы $deadline=''; if (isset($_POST['deadline'])) {
    $deadline = $_POST['deadline'];
}*/
$needTimeStamp = time()+(60*60*24*$deadline);
/*echo $needTimeStamp;
echo '<br>';

$ts=$needTimeStamp - (time()+11400);
echo $ts;
echo '<br>';
echo date('j',$ts);
echo '<br>';*/
if (!empty($task) && !empty($deadline)) {



        $fw = fopen("table.txt", 'a');
        $str = $task . '&' . $needTimeStamp . '&' . PHP_EOL;
        fwrite($fw, $str);
        fclose($fw);
    }

