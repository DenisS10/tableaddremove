<?php
$files = scandir(__DIR__);
echo $files;
echo time();